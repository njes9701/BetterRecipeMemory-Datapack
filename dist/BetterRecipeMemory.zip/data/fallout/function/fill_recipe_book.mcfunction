recipe give @s *
